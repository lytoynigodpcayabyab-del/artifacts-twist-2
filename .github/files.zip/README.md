# Artifact plugin v2 (Paper 1.21.4+, Java 21)

Plugin name is `Artifact`, so every command also works with the prefix: `/artifact:offhand`, `/artifact:recipe` ...

## Core rules
* Everything (passives, +5 hearts, abilities) works ONLY while the artifact is in the **offhand**.
* Equip: hold the artifact in your main hand and press **F**. (While an artifact is already in the offhand, F fires Ability 1 instead
  of swapping. To take it out, use your inventory screen.)
* **F** = Ability 1, **Shift + F** = Ability 2 (or `/artifact:offhand`, `/artifact:crouchoffhand`).
* Fatal damage with an artifact in the offhand: totem animation, health restored, artifact destroyed (not for /kill or void).

## Commands
| Command | Permission |
|---|---|
| `/artifact:offhand`, `/artifact:crouchoffhand` | artifact.use |
| `/artifact:recipe` (GUI) | artifact.use |
| `/artifact:cooldown` (reset your cooldowns) | artifact.admin |
| `/artifact:ritual summon <artifact> <seconds>` / `stop` | artifact.admin |
| `/artifact give <player> <artifact> [amount]`, `list`, `reload` | artifact.admin |

`artifact.bypass` = immune to domain / pull / laser / radar / aura (staff).
IDs: `star_of_invisibility`, `void_capsule`, `particle_ray_array`, `vitalis_relic`

## Updating an existing GitHub repo
1. Repo > open the `src` folder > "..." menu > **Delete directory** > commit.
2. **Add file > Upload files**: drag in the new `src` folder, `pom.xml`, `README.md` (keep your existing `.github` folder).
3. Actions tab > wait for the green check > download `TwistArtifacts-jar`, extract `TwistArtifacts.jar`.
4. On the server: upload it over the old `TwistArtifacts.jar` (same name = replaced), then fully restart.
